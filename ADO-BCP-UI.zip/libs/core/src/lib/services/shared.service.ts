/* eslint-disable @nrwl/nx/enforce-module-boundaries */

import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import {
  ApiService,
  ImenuElement,
  InotificationElement,
  IpopupElement,
  ItileElement,
  environment,
} from '@ado-bcp-ui/core';

@Injectable({
  providedIn: 'root',
})
export class SharedService {
  constructor(private apiService: ApiService) {}

  getNotificationDetails(): Observable<InotificationElement> {
    return this.apiService.get(`${environment.api_url}/notifications`).pipe(
      map((data) => {
        return data;
      })
    );
  }
  getBackupPopupDetails(): Observable<IpopupElement> {
    return this.apiService.get(`${environment.api_url}/popupTitle`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getMenuDetails(): Observable<ImenuElement> {
    return this.apiService.get(`${environment.api_url}/menuElement`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getDashboardTileDetails(): Observable<ItileElement> {
    return this.apiService.get(`${environment.api_url}/titleData`).pipe(
      map((data) => {
        return data;
      })
    );
  }
}
