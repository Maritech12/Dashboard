import { SharedService } from '@ado-bcp-ui/core';
import { MediaMatcher } from '@angular/cdk/layout';
import { Component, ChangeDetectorRef, OnInit } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
})
export class SidebarComponent implements OnInit {
  menuElement: any = [];

  color = false;
  panelOpenState = false;

  mobileQuery: MediaQueryList;

  private _mobileQueryListener: () => void;

  constructor(
    changeDetectorRef: ChangeDetectorRef,
    media: MediaMatcher,
    private sharedService: SharedService
  ) {
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
  }

  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
  }

  // eslint-disable-next-line @typescript-eslint/no-empty-function
  ngOnInit(): void {
    this.sharedService.getMenuDetails().subscribe((data) => {
      this.menuElement = data;
    });
  }
}
