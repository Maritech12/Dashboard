import { Component, OnInit } from '@angular/core';
import { MsalService } from '@azure/msal-angular';
import { UserService } from '@ado-bcp-ui/core';

@Component({
  selector: 'ado-bcp-ui-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss'],
})
export class UserComponent implements OnInit {
  user: any = {
    userName: '',
    userNameLabel: 'Username',
    settingsLabel: 'Settings',
    logoutLabel: 'Logout',
  };
  userDetails: any;
  constructor(
    private userService: UserService,
    private msalService: MsalService
  ) {}

  ngOnInit(): void {
    this.userService.currentUser.subscribe(
      (msg: any) => (this.userDetails = msg)
    );
  }

  logout() {
    this.userService.purgeAuth();
    this.msalService.logout();
  }
}
