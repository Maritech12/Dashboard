module.exports = {
  name: 'ado-vault.dashboard',
  exposes: {
    './Module': 'apps/ado-vault.dashboard/src/app/remote-entry/entry.module.ts',
  },
};
