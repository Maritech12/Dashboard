/* eslint-disable @angular-eslint/contextual-lifecycle */
import { SharedService, UserService } from '@ado-bcp-ui/core';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { MsalService } from '@azure/msal-angular';

@Injectable({
  providedIn: 'root',
})
export class MSALLoginService {
  userDetails!: any;

  constructor(
    private sharedService: SharedService,
    private msalService: MsalService,
    private router: Router,
    private userService: UserService
  ) {}

  msallogin() {
    this.msalService.instance.handleRedirectPromise().then((res) => {
      if (res != null && res.account != null) {
        this.userDetails = {
          email: res.account.username,
          token: res.account.tenantId,
          name: res.account.name,
        };
        this.msalService.instance.setActiveAccount(res.account);
        this.userService.setAuth(this.userDetails);
        this.router.navigate(['/ado-vault.dashboard']);
      } else {
        this.userService.purgeAuth();
        this.msalService.loginRedirect();
      }
    });
  }
}
