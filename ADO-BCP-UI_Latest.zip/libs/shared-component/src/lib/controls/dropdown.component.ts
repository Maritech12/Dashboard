import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.scss'],
})
export class DropdownComponent implements OnInit {
  @Input() ddlElement:any;
  selectedOption = 'option1';    
  constructor() {}

  ngOnInit(): void {}
}
