declare module 'ado-vault.backup/Module';

declare module 'ado-vault.company/Module';

declare module 'ado-vault.entity/Module';

declare module 'ado-vault.integration/Module';

declare module 'ado-vault.user-management/Module';

declare module 'ado-vault.report/Module';

declare module 'ado-vault.restore/Module';

declare module 'ado-vault.role/Module';

declare module 'ado-vault.storage/Module';

declare module 'ado-vault.notification/Module';

declare module 'ado-vault.dashboard/Module';
