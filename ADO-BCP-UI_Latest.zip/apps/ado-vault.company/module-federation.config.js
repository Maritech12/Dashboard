module.exports = {
  name: 'ado-vault.company',
  exposes: {
    './Module': 'apps/ado-vault.company/src/app/remote-entry/entry.module.ts',
  },
};
