import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-days',
  templateUrl: './days.component.html',
  styleUrls: ['./days.component.scss'],
})
export class DaysComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
