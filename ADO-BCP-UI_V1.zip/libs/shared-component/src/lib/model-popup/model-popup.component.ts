import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-model-popup',
  templateUrl: './model-popup.component.html',
  styleUrls: ['./model-popup.component.scss'],
})
export class ModelPopupComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
