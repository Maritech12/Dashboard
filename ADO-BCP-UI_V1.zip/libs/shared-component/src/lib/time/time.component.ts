import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-time',
  templateUrl: './time.component.html',
  styleUrls: ['./time.component.scss'],
})
export class TimeComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
