import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-multi-select',
  templateUrl: './multi-select.component.html',
  styleUrls: ['./multi-select.component.scss'],
})
export class MultiSelectComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
