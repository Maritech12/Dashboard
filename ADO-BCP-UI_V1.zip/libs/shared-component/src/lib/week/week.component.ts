import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-week',
  templateUrl: './week.component.html',
  styleUrls: ['./week.component.scss'],
})
export class WeekComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
