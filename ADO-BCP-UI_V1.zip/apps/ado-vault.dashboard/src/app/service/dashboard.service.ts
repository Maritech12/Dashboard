/* eslint-disable @typescript-eslint/no-explicit-any */
import { ApiService } from '@ado-bcp-ui/core';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { IcolumnElement } from '../models/dashboard.model';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class DashboardService {
  constructor(private apiService: ApiService) {} 

  getBackupDetails(): Observable<IcolumnElement> {
    return this.apiService.get(`${environment.api_url}/getBackupDetails`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getRestoreDetails(): Observable<IcolumnElement> {
    return this.apiService.get(`${environment.api_url}/getRestoreDetails`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getProjectDetails(): Observable<IcolumnElement> {
    return this.apiService.get(`${environment.api_url}/ddlProjectData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getPeriodsDetails(): Observable<IcolumnElement> {
    return this.apiService.get(`${environment.api_url}/ddlPeriodData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getUserDetails(): Observable<IcolumnElement> {
    return this.apiService.get(`${environment.api_url}/Dashboard/GetUserDetail`).pipe(
      map((data) => {
        return data;
      })
    );
  }
}
