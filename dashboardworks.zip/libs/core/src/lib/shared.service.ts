/* eslint-disable @nrwl/nx/enforce-module-boundaries */

import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import {
  ApiService,
  IcolumnElement,
  ImenuElement,
  InotificationElement,
  IpopupElement,
  ItileElement,
} from '@ado-bcp-ui/core';

@Injectable({
  providedIn: 'root',
})
export class SharedService {
  constructor(private apiService: ApiService) {}
  
  notification(): Observable<InotificationElement> {
    return this.apiService.get('notifications').pipe(
      map((data) => {
        return data;
      })
    );
  }
  popupTitle(): Observable<IpopupElement> {
    return this.apiService.get('popupTitle').pipe(
      map((data) => {
        return data;
      })
    );
  }

  menuElement(): Observable<ImenuElement> {
    return this.apiService.get('menuElement').pipe(
      map((data) => {
        return data;
      })
    );
  }

  titleData(): Observable<ItileElement> {
    return this.apiService.get('titleData').pipe(
      map((data) => {
        return data;
      })
    );
  }

  tableDataSource(): Observable<IcolumnElement> {
    return this.apiService.get('tableDataSource').pipe(
      map((data) => {
        return data;
      })
    );
  }

  ddlProjectData(): Observable<IcolumnElement> {
    return this.apiService.get('ddlProjectData').pipe(
      map((data) => {
        return data;
      })
    );
  }

  ddlPeriodData(): Observable<IcolumnElement> {
    return this.apiService.get('ddlPeriodData').pipe(
      map((data) => {
        return data;
      })
    );
  }
}
