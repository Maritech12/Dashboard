import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.scss'],
})
export class GridComponent implements OnInit {
  displayedColumns = [
    'name',
    'position',
    'position',
    'weight',
  ];
  dataSource = ELEMENT_DATA;

  constructor() {}

  ngOnInit(): void {}
}

export interface PeriodicElements {
  name: string;
  position: number;
  weight: number;
}

const ELEMENT_DATA: PeriodicElements[] = [
  {position: 1, name: 'Hydrogen', weight: 1.0079},
  {position: 2, name: 'Helium', weight: 4.0026},
];
