/* eslint-disable @nrwl/nx/enforce-module-boundaries */
import { SharedService } from '@ado-bcp-ui/core';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-tile',
  templateUrl: './tile.component.html',
  styleUrls: ['./tile.component.scss'],
})
export class TileComponent implements OnInit {
  constructor(private sharedService: SharedService) {}

  titleElement: any;

  ngOnInit(): void {
    this.sharedService.titleData().subscribe((data) => {
      this.titleElement = data;
    });
  }
}
