import { Component } from '@angular/core';
@Component({
  selector: 'ado-bcp-ui-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent {
  dropdownOpen = false;
  // constructor(
  //   @Inject(DOCUMENT) private document: Document,) {}

  sidebarToggle() {
    //toggle sidebar function
    //this.document.body.classList.toggle('toggle-sidebar');
  }

  logout() {
    //localStorage.removeItem('userDetails');
    //this.msalService.logout();
  }
}
