interface IcolumnElement {
    entity: string;
    subentity: string;
    initiatedAt: string;
    completedAt: string;
    status: string;
    action: string;
  }
  
  interface ItileElement {
    id: number;
    status: string;
    BackupCount: number;
    RestoreCount: number;
  }
  
  interface IpopupElement {
    title: string;
    contentElement: string[];
  }
  
  export { IcolumnElement, ItileElement, IpopupElement };
  