/* eslint-disable @typescript-eslint/no-explicit-any */
import { SharedService } from '@ado-bcp-ui/core';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class DashboardService {
  constructor(private sharedService: SharedService) {}

  tableDataSource(): Observable<any> {
    return this.sharedService.tableDataSource().pipe(
      map((data) => {
        return data;
      })
    );
  }
  ddlProjectData(): Observable<any> {
    return this.sharedService.ddlProjectData().pipe(
      map((data) => {
        return data;
      })
    );
  }
  ddlPeriodData(): Observable<any> {
    return this.sharedService.ddlPeriodData().pipe(
      map((data) => {
        return data;
      })
    );
  }
}
