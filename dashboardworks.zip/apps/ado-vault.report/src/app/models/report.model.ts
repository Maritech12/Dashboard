export class ReportModel {}
