module.exports = {
  name: 'ado-vault.report',
  exposes: {
    './Module': 'apps/ado-vault.report/src/app/remote-entry/entry.module.ts',
  },
};
