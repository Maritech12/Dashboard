import { Route } from '@angular/router';
import { RestoreComponent } from '../components/restore.component';

export const remoteRoutes: Route[] = [
  { path: '', component: RestoreComponent },
];
